﻿
namespace YmtSystem.CrossCutting
{
    public enum TaskContinuation
    {
        Continue,
        Break
    }
}
