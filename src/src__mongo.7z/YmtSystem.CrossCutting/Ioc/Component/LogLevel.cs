﻿
namespace YmtSystem.CrossCutting
{
    public enum LogLevel
    {
        None = 99,
        Debug = 1,
        Info = 2,
        Warning = 3,
        Error = 4
    }
}
