﻿namespace YmtSystem.CrossCutting.Aop.Cache
{
    using System;
    public enum CachedTimeType
    {
        Minute = 0,
        Second = 1,
        Hour = 1,
    }
}
