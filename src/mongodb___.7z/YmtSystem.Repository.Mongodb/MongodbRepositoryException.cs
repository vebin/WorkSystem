﻿namespace YmtSystem.Repository.Mongodb
{
    using YmtSystem.CrossCutting;
    public class MongodbRepositoryException : ExceptionArgs
    {
    }
}
