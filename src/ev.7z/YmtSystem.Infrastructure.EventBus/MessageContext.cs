﻿namespace YmtSystem.Infrastructure.EventBusService
{
    using System;

    public class MessageContext
    {
        public bool AsyncReceive { get; set; }
        public int Retry { get; set; }
        public bool Monitor { get; set; }
        public bool HandleResult { get; set; }
        public object Context { get; set; }
        public bool PersistentStore { get; set; }
    }
}
