﻿namespace YmtSystem.Infrastructure.EventBusService
{
    using System;
    /// <summary>
    /// 事件标识接口
    /// <remarks>注：正式版使用时，直接使用 Ymatou.MQ.Event 事件驱动功能</remarks>
    /// </summary>
    public interface IEvent
    {
        string EventKey { get; set; }
        DateTime TriggerTime { get; set; }
    }
}
