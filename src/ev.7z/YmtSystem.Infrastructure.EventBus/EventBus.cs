﻿namespace YmtSystem.Infrastructure.EventBusService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Concurrent;

    public partial class EventBus<TEvent> where TEvent : IEvent
    {
        private ConcurrentQueue<TEvent> ebContainer = new ConcurrentQueue<TEvent>();
        private IEventHandler<TEvent> handlerContainer;
        private static readonly Lazy<EventBus<TEvent>> lazy = new Lazy<EventBus<TEvent>>(() => new EventBus<TEvent>(), true);
        public static EventBus<TEvent> Instance
        {
            get { return lazy.Value; }
        }
        private EventBus()
        {
        }
        public void Publish(TEvent @event)
        {
            EventAssert.AssertEventNotNull(@event);
            PbulishEvent(@event);
            ObServer();
        }

        public void Publish(IEnumerable<TEvent> @event)
        {
            foreach (var e in @event)
            {
                EventAssert.AssertEventNotNull(e);
                PbulishEvent(e);
            }
            ObServer();
        }
        public void UnSubscribe(TEvent subEvent)
        {
            this.handlerContainer = null;
        }
        public void Subscribe(IEventHandler<TEvent> handler, TEvent subEvent)
        {
            this.handlerContainer = handler;
        }
        public void Clear()
        {
            this.handlerContainer = null;
        }
        private void PbulishEvent(TEvent @event)
        {
            if (ebContainer.Count <= 10000)
                ebContainer.Enqueue(@event);
            else
                throw new Exception("事件超出最大数量");
        }

        private void ObServer()
        {
            EventAssert.AssertEventHandlerNotNull(handlerContainer, "为注册事件处理程序");
            while (ebContainer.Any())
            {
                TEvent defEvent;
                if (ebContainer.TryDequeue(out defEvent))
                {
                    handlerContainer.Handle(defEvent);
                }
            }
        }
    }

    public partial class EventBus
    {
        private ConcurrentDictionary<string, ConcurrentQueue<dynamic>> eventContainer = new ConcurrentDictionary<string, ConcurrentQueue<dynamic>>();
        private ConcurrentDictionary<string, dynamic> handlerContainer = new ConcurrentDictionary<string, dynamic>();
        private static readonly Lazy<EventBus> lazy = new Lazy<EventBus>(() => new EventBus(), true);
        public static EventBus Instance
        {
            get { return lazy.Value; }
        }
        private EventBus()
        {
        }
        public void Publish<TEvent>(TEvent @event) where TEvent : IEvent
        {
            var _eventName = typeof(TEvent).FullName;
            EnsureEventContainer(_eventName);
            PbulishEvent(@event, _eventName);
            ConsumerEvent();
        }
        public void Publish<TEvent>(IEnumerable<TEvent> @event) where TEvent : IEvent
        {
            var _eventName = typeof(TEvent).FullName;
            foreach (var _e in @event)
            {
                EnsureEventContainer(_eventName);
                PbulishEvent(_e, _eventName);
            }
            ConsumerEvent();
        }
        public void Subscribe<TEvent>(IEventHandler<TEvent> handler) where TEvent : IEvent
        {
            var _eventFullNmae = typeof(TEvent).FullName;
            if (!handlerContainer.ContainsKey(_eventFullNmae))
                handlerContainer[_eventFullNmae] = handler;
        }
        public void UnSubscribe<TEvent>() where TEvent : IEvent
        {
            var _eventFullNmae = typeof(TEvent).FullName;
            if (handlerContainer.ContainsKey(_eventFullNmae))
            {
                object o;
                handlerContainer.TryRemove(_eventFullNmae, out o);
                if (o != null)
                {
                    ConsumerEvent();
                }
            }
        }
        private void ConsumerEvent()
        {
            foreach (var handler in handlerContainer)
            {
                ConcurrentQueue<dynamic> eq;
                if (eventContainer.TryGetValue(handler.Key, out eq))
                {
                    while (eq.Any())
                    {
                        dynamic o;
                        if (eq.TryDequeue(out o))
                        {
                            try
                            {
                                handler.Value.Handle(o);
                            }
                            catch (Exception ex)
                            {
                                YmtSystem.CrossCutting.YmatouLoggingService.Error("event handler error {0}", ex.ToString());
                            }
                        }
                    }
                }
            }
        }
        private void PbulishEvent(object @event, string @eventFullName)
        {
            eventContainer[@eventFullName].Enqueue(@event);
        }
        private void EnsureEventContainer(string @eventFullName)
        {
            if (!eventContainer.ContainsKey(@eventFullName))
            {
                eventContainer[@eventFullName] = new ConcurrentQueue<dynamic>();
            }
        }
    }
}
