﻿namespace YmtSystem.Infrastructure.EventBusService
{
    using System;
    public interface IEventHandler<TEvent> where TEvent : IEvent
    {
        void Handle(TEvent domainEvent);        
    }
}
