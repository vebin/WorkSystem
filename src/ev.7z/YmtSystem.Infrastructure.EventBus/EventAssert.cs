﻿namespace YmtSystem.Infrastructure.EventBusService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class EventAssert
    {
        public static void AssertEventNotNull(object @event, string errMsg = "@event not null")
        {
            if (@event == null) { }
        }
        public static void AssertEventHandlerNotNull(object @event, string errMsg = "@event not null")
        {
            if (@event == null) { }
        }
    }
}
