﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YmtSystem.Infrastructure.EventStore
{
    public class Class1
    {
    }
}
