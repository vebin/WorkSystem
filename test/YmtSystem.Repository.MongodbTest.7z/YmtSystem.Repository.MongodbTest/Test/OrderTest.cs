﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using YmtSystem.Repository.MongodbTest.Repository;

namespace YmtSystem.Repository.MongodbTest.Test
{
    public class OrderTest
    {
       
    }
}
